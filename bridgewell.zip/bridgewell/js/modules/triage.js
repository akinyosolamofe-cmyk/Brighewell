/* modules/triage.js — "What's getting in the way?" chips that filter services. */
(function (App) {
  const { $, el } = App.utils;
  const { needs, services, categoryLabels } = App.data;

  function renderCard(service) {
    return el("article", { class: "card card--lift" },
      el("span", { class: `tag tag--${service.category}` }, categoryLabels[service.category]),
      el("h3", {}, service.title),
      el("p", {}, service.text),
      el("a", { class: "card__link", href: service.href }, service.cta),
      el("p", { class: "card__meta" }, service.meta)
    );
  }

  function init() {
    const chipsBox = $("#triage-chips");
    const results = $("#triage-results");
    if (!chipsBox || !results) return;

    const chips = needs.map((need) => {
      const chip = el("button", { type: "button", class: "chip", "aria-pressed": "false", "data-need": need.id }, need.label);
      chipsBox.append(chip);
      return chip;
    });

    function select(needId) {
      chips.forEach((c) => c.setAttribute("aria-pressed", String(c.dataset.need === needId)));
      const matches = needId === "all" ? services : services.filter((s) => s.needs.includes(needId));
      results.replaceChildren(...matches.map(renderCard));
    }

    chipsBox.addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (chip) select(chip.dataset.need);
    });

    // Start with something useful on screen rather than an empty box.
    select("mind");
  }

  App.modules.triage = { init };
})(window.App);
