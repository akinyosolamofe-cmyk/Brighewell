/* modules/insurance.js — plan cards and the yearly cost estimator. */
(function (App) {
  const { $, el, money, num } = App.utils;
  const { plans } = App.data;

  /** Yearly cost = 12 premiums + visit fees (capped at the plan's out-of-pocket max). */
  function yearlyCost(plan, visits) {
    const visitFees = Math.min(plan.copay * visits, plan.outOfPocketMax);
    return plan.premium * 12 + visitFees;
  }

  function renderPlans() {
    const box = $("#plans");
    if (!box) return;
    box.replaceChildren(...plans.map((plan) =>
      el("article", { class: `card plan${plan.best ? " plan--best" : ""}` },
        plan.best && el("span", { class: "plan__badge" }, "Most chosen"),
        el("h3", {}, plan.name),
        el("p", { class: "plan__price" }, money(plan.premium), el("small", {}, " / month")),
        el("ul", { class: "plan__features" }, plan.features.map((f) => el("li", {}, f))),
        el("p", { class: "card__meta" }, `Visit fee: ${money(plan.copay)}. Visit fees capped at ${money(plan.outOfPocketMax)} a year.`)
      )
    ));
  }

  function renderEstimate() {
    const slider = $("#visits");
    const label = $("#visits-value");
    const out = $("#estimate-result");
    if (!slider || !out) return;

    const visits = num(slider);
    label.textContent = visits === 1 ? "1 visit" : `${visits} visits`;

    const rows = plans.map((p) => ({ plan: p, total: yearlyCost(p, visits) }));
    const cheapest = Math.min(...rows.map((r) => r.total));

    out.replaceChildren(...rows.map(({ plan, total }) =>
      el("div", { class: `estimator__row${total === cheapest ? " estimator__row--cheapest" : ""}` },
        el("span", {}, plan.name, total === cheapest ? " (lowest for you)" : ""),
        el("strong", {}, `${money(total)} / year`)
      )
    ));
  }

  function init() {
    renderPlans();
    const slider = $("#visits");
    if (slider) slider.addEventListener("input", renderEstimate);
    renderEstimate();
  }

  App.modules.insurance = { init, yearlyCost };
})(window.App);
