/* modules/support.js — renders the support-services grid and aid cards. */
(function (App) {
  const { $, el } = App.utils;

  function init() {
    const list = $("#support-list");
    if (list) {
      const items = App.data.services.filter((s) => s.category === "support");
      list.replaceChildren(...items.map((s) =>
        el("article", { class: "card" },
          el("h3", {}, s.title),
          el("p", {}, s.text),
          el("p", { class: "card__meta" }, s.meta)
        )
      ));
    }

    const aid = $("#aid-list");
    if (aid) {
      aid.replaceChildren(...App.data.aid.map((a) =>
        el("article", { class: "card" },
          el("span", { class: "tag tag--money" }, a.tag),
          el("h3", {}, a.title),
          el("p", {}, a.text)
        )
      ));
    }
  }

  App.modules.support = { init };
})(window.App);
