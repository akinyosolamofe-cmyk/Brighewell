/* modules/contact.js — contact form validation.
   Nothing is sent anywhere yet: replace the TODO in submit() with a real endpoint. */
(function (App) {
  const { $ } = App.utils;

  const RULES = {
    name:    (v) => (v.trim().length >= 2 ? "" : "Enter your name."),
    email:   (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? "" : "Enter an email address like name@school.edu."),
    topic:   (v) => (v ? "" : "Choose what you need help with."),
    message: (v) => (v.trim().length >= 10 ? "" : "Write at least a sentence so we can help."),
  };

  function validateField(field) {
    const error = RULES[field.name](field.value);
    field.setAttribute("aria-invalid", String(Boolean(error)));
    $("#" + field.id + "-error").textContent = error;
    return !error;
  }

  function init() {
    const form = $("#contact-form");
    if (!form) return;
    const fields = Object.keys(RULES).map((name) => form.elements[name]);
    const status = $("#contact-status");

    fields.forEach((f) => f.addEventListener("blur", () => validateField(f)));

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const results = fields.map(validateField); // validate all, don't stop at first
      if (results.includes(false)) {
        fields[results.indexOf(false)].focus();
        return;
      }
      // TODO: send form data to your backend here.
      status.hidden = false;
      status.textContent = "Sent. An adviser will reply within 2 working days.";
      form.reset();
    });
  }

  App.modules.contact = { init };
})(window.App);
