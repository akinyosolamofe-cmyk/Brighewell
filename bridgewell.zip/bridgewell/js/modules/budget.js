/* modules/budget.js — monthly budget planner. */
(function (App) {
  const { $, $$, money, num } = App.utils;

  const COSTS = [
    { id: "rent",      label: "Rent",      color: "#2547D0" },
    { id: "food",      label: "Food",      color: "#1F7A57" },
    { id: "transport", label: "Transport", color: "#FFC83D" },
    { id: "books",     label: "Books",     color: "#E07A5F" },
    { id: "other",     label: "Other",     color: "#7A8794" },
  ];

  function render() {
    const income = num($("#b-income"));
    const amounts = COSTS.map((c) => ({ ...c, value: num($("#b-" + c.id)) }));
    const spent = amounts.reduce((sum, c) => sum + c.value, 0);
    const left = income - spent;

    const leftEl = $("#budget-left");
    leftEl.textContent = money(left);
    leftEl.classList.toggle("budget__left--negative", left < 0);

    $("#budget-message").textContent =
      income === 0 ? "Add your monthly income to see what is left."
      : left < 0 ? `You are ${money(-left)} short each month. The hardship fund and money advice can help.`
      : left === 0 ? "Every dollar is spoken for, so there is no cushion for surprises."
      : `You have ${money(left)} left each month. Setting some aside builds a buffer.`;

    // Bars are scaled to whichever is larger: income or spending.
    const base = Math.max(income, spent, 1);
    $("#budget-meter").replaceChildren(...amounts.filter((c) => c.value > 0).map((c) => {
      const part = document.createElement("div");
      part.className = "meter__part";
      part.style.width = (c.value / base) * 100 + "%";
      part.style.background = c.color;
      part.title = `${c.label}: ${money(c.value)}`;
      return part;
    }));
  }

  function init() {
    const form = $("#budget-form");
    if (!form) return;
    $("#budget-legend").innerHTML = COSTS.map((c) => `<span><i style="background:${c.color}"></i>${c.label}</span>`).join("");
    $$("input", form).forEach((i) => i.addEventListener("input", render));
    form.addEventListener("submit", (e) => e.preventDefault());
    render();
  }

  App.modules.budget = { init };
})(window.App);
