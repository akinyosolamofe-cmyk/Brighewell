/* modules/pwa.js — registers the service worker and offers an "Install app" button. */
(function (App) {
  const { $ } = App.utils;

  function init() {
    if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    }

    // Android/Chrome fires this when the site can be installed.
    let deferred = null;
    const button = $("#install-app");
    window.addEventListener("beforeinstallprompt", (e) => {
      e.preventDefault();
      deferred = e;
      if (button) button.hidden = false;
    });
    if (button) {
      button.addEventListener("click", async () => {
        if (!deferred) return;
        deferred.prompt();
        await deferred.userChoice;
        deferred = null;
        button.hidden = true;
      });
    }
    window.addEventListener("appinstalled", () => { if (button) button.hidden = true; });
  }

  App.modules.pwa = { init };
})(window.App);
