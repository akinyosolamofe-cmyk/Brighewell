/* config.js — site-wide settings. Loaded first; creates the App namespace. */
window.App = {
  config: {
    currency: "USD",
    locale: "en-US",
    averageVisitCost: 120, // used by the insurance estimator
  },
  data: {},
  modules: {},
};
