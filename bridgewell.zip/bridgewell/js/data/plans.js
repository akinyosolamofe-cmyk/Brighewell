/* data/plans.js — health insurance plans (sample figures).
   copay: what you pay per visit. outOfPocketMax: most you pay in a year on visits. */
App.data.plans = [
  {
    id: "essential",
    name: "Essential",
    premium: 38,
    copay: 40,
    outOfPocketMax: 2500,
    features: ["Emergency care", "GP visits", "Prescriptions at 50%"],
  },
  {
    id: "standard",
    name: "Standard",
    premium: 72,
    copay: 20,
    outOfPocketMax: 1500,
    best: true,
    features: ["Everything in Essential", "Mental health visits", "Prescriptions at 80%"],
  },
  {
    id: "complete",
    name: "Complete",
    premium: 118,
    copay: 0,
    outOfPocketMax: 500,
    features: ["Everything in Standard", "Dental and vision", "No visit fees"],
  },
];
