/* data/needs.js — the chips shown in the hero triage. */
App.data.needs = [
  { id: "mind",    label: "I feel overwhelmed" },
  { id: "study",   label: "I'm falling behind" },
  { id: "health",  label: "I need health cover" },
  { id: "money",   label: "Money is tight" },
  { id: "housing", label: "I need somewhere to live" },
  { id: "all",     label: "Show everything" },
];

App.data.categoryLabels = { support: "Support", health: "Health", money: "Money" };
