/* main.js — entry point. Starts every module once the page has loaded. */
(function (App) {
  function start() {
    Object.values(App.modules).forEach((module) => module.init());
    document.getElementById("year").textContent = new Date().getFullYear();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})(window.App);
