/* utils.js — small helpers shared by every module. */
(function (App) {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  /** Format a number as money using the site config. */
  function money(value) {
    return new Intl.NumberFormat(App.config.locale, {
      style: "currency",
      currency: App.config.currency,
      maximumFractionDigits: 0,
    }).format(value);
  }

  /** Create an element: el("div", { class: "card" }, "text" | node, ...) */
  function el(tag, attrs = {}, ...children) {
    const node = document.createElement(tag);
    for (const [key, val] of Object.entries(attrs)) {
      if (val === false || val == null) continue;
      node.setAttribute(key, val === true ? "" : val);
    }
    for (const child of children.flat()) {
      node.append(child instanceof Node ? child : document.createTextNode(child));
    }
    return node;
  }

  /** Read a number from an input, treating blanks and negatives as 0. */
  function num(input) {
    const n = parseFloat(input.value);
    return Number.isFinite(n) && n > 0 ? n : 0;
  }

  App.utils = { $, $$, money, el, num };
})(window.App);
