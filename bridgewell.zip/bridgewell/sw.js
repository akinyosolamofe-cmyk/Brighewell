/* sw.js — service worker: caches the site so it opens offline.
   Bump CACHE_VERSION whenever you change any file below. */
const CACHE_VERSION = "bridgewell-v1";
const FILES = [
  "./", "./index.html", "./manifest.webmanifest",
  "./css/tokens.css", "./css/base.css", "./css/layout.css", "./css/components.css", "./css/sections.css",
  "./js/config.js", "./js/utils.js", "./js/main.js",
  "./js/data/needs.js", "./js/data/services.js", "./js/data/plans.js",
  "./js/modules/nav.js", "./js/modules/triage.js", "./js/modules/support.js",
  "./js/modules/insurance.js", "./js/modules/budget.js", "./js/modules/contact.js", "./js/modules/pwa.js",
  "./icons/icon-192.png", "./icons/icon-512.png", "./icons/icon-maskable-512.png",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE_VERSION).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Cache first for our own files; network (with a cached fallback) for everything else, e.g. fonts.
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request).then((hit) => hit || fetch(e.request).catch(() => caches.match("./index.html")))
  );
});
