# Bridgewell Student Services

A static website for student support, health insurance and financial services. No build step: open `index.html` in a browser.

## Structure

```
bridgewell/
├── index.html              Page markup, one <section> per topic
├── css/
│   ├── tokens.css          Colors, type scale, spacing (edit the look here)
│   ├── base.css            Reset and element defaults
│   ├── layout.css          Containers, grids, header, footer
│   ├── components.css      Buttons, cards, forms, chips, accordion
│   └── sections.css        Styles for one section only
└── js/
    ├── config.js           Currency, locale, App namespace
    ├── utils.js            Shared helpers ($, el, money)
    ├── data/               Content as data: needs, services, aid, plans
    ├── modules/            One file per feature: nav, triage, support,
    │                       insurance, budget, contact
    └── main.js             Starts every module
```

## Common changes

| To change | Edit |
|---|---|
| Colors, fonts, spacing | `css/tokens.css` |
| Services and aid wording | `js/data/services.js` |
| Insurance plans and prices | `js/data/plans.js` |
| Currency | `js/config.js` |
| Where the contact form sends | `js/modules/contact.js` (see the TODO) |

All names, prices and contacts are samples. Replace them before publishing.

## Phone app (PWA)

`manifest.webmanifest`, `sw.js`, `icons/` and `js/modules/pwa.js` make the site installable and usable offline.
It must be served over **HTTPS** (not opened as a file). Free options: Netlify Drop, Cloudflare Pages, GitHub Pages.
- Android (Chrome): open the site, tap **Install app** (or menu → Install app).
- iPhone (Safari): Share → **Add to Home Screen**.
After changing any file, bump `CACHE_VERSION` in `sw.js` so phones pick up the update.
